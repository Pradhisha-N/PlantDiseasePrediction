
#### Why this folder ?
At the Runtime what ever local image will test that are saved in this folder and use this folder path in model prediction phase. 
